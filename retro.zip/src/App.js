import React, { Component } from 'react';
import Landingpage from './components/landingpage/landing';
import Createretro from './components/createretro/createretro';
import {BrowserRouter as Router,Route ,
  Link,Switch ,
  Redirect,
  } from 'react-router-dom';
import {Provider } from 'react-redux';
import store from '../src/store/index';
import history from './History';



function PrivateRoute({component : Component,authed, ...rest}){
  return(
          <Route 
            {...rest}
              render={(props) => authed === true 
                ?   <Component {...props} />
              : <Redirect to={{pathname : '/', state: {from: props.location}} }  /> }
              />
  )
}



class App extends Component {
  constructor(props){
      super(props);
      this.state = {
        authed : false
      }
  }

    componentWillMount(){
       let data = localStorage.getItem('userdata');
       console.log(JSON.parse(data).token);
       if(JSON.parse(data).token){
         this.setState({authed : true});
       }
       else{
         this.setState({authed: false})
       }
    }


  render() {
    return (


    //  <Createretro />
      <Provider store={store}>
     
      <Router history={history} >
          <Switch>

    <div>
      <Route exact path="/" component={Landingpage}/>
      {/* <Route path="/createretro" component={Createretro} /> */}
      <PrivateRoute authed={this.state.authed} path="/createretro" component={Createretro} />
            {/* <Createretro />   */}
      </div>
          </Switch>
      </Router>
      </Provider>
    );
  }
}

export default App;
