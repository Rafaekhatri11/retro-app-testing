const myActions= {
    userlogin :'',
    authenticate : false
   
}

export default myActions;