import myActions from '../constant/constant';


export function getpatients(array){
    return dispatch => {
        dispatch({type :myActions.getpatients , payload : array})
    }
}

export function userlogin(data){
    return dispatch => {

      
    }
}