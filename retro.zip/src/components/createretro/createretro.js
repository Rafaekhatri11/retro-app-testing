import React, { Component } from 'react';
import {
  Navbar, Nav, NavItem,
  Button, MenuItem, NavDropdown, FormControl, Tabs, Tab,
  Table, Modal, Form, FormGroup, ControlLabel
} from 'react-bootstrap';
import logo from './Selection_003.png';
import personlogo from './dropdownpersion.png';
import { caretRight } from 'react-icons-kit/fa/caretRight';
import { checkCircle } from 'react-icons-kit/fa/checkCircle';
import Icon from 'react-icons-kit';
import { ic_close } from 'react-icons-kit/md/ic_close';
import './style.css';
var jwt = require('jsonwebtoken');
class Createretro extends Component {
  constructor() {
    super();
    this.state = {
      userinfo: {},
      edit : false,
      projectname : false,
      nameofproject: '',
      show :false,
      show1:false,
      templatename : '',
      whatdidwelearn: '',
      whatdidwemiss : '',
      whatcanweimprove : '',
      whatpuzzleus :''
   }
  }
  componentDidMount() {
    var data = localStorage.getItem('userdata');
    var userdata = JSON.parse(data);


    // jwt.verify(userdata.token, 'secret', (err, decoded) => {
    //   console.log(decoded);
    //   this.setState({ userinfo: decoded })

    // });

    //this timeout is used for check user information thorugh api is takes some time
    //  setTimeout(() => {console.log(this.state.userinfo)} ,5000);
  }

  handleHide() {
    this.setState({ show: false });
  }

  handleHide1(){
    this.setState({show1: false});
  }
  getprojectnam(evt){
      if(evt.target.value === "New Project"){
        this.setState({show: true})
      }
      else{
        this.setState({nameofproject: evt.target.value});
      }
  }

  gettemplatename(evt){
    // if(evt.target.value === "New Template"){
    //   this.setState({show1 : true});
    // }
    // else{
      this.setState({templatename: evt.target.value});
    // }
  }
  logout() {
    localStorage.clear();
    this.props.history.push('/');


  }
  render() {
    console.log(this.state.nameofproject);
    return (
      
      <div id="createretrobackground">
        <div style={{ background: 'rgba(255,255,255,0.5' }}>

          <Navbar style={{ height: 60, background: 'rgba(255,255,255,0.5)', }} collapseOnSelect>
            <Navbar.Header>
              <Navbar.Brand>
                <img src={logo} alt="Retro" width="140" style={{ height: 60 }} />
              </Navbar.Brand>
              <Navbar.Toggle />
            </Navbar.Header>
            <Navbar.Collapse>

              <Nav style={{ paddingTop: 5, justifyContent: 'space-around' }} pullRight>

                <NavDropdown className="mydropdown" title={<div style={{ display: 'inline-flex', height: 20, bottom: 0 }}><p style={{ color: "#133a62", paddingTop: 2 }}>Hi, Bob!</p><img width="25" height="25" style={{ marginLeft: 15, background: 'none' }} src={personlogo} /></div>}  >

                  <MenuItem style={{ textAlign: 'right', background: "#133a62", color: 'white' }} >My Profile</MenuItem>
                  <MenuItem style={{ textAlign: 'right', background: "#133a62", color: 'white' }}>Enterprise Account</MenuItem>
                  <MenuItem style={{ textAlign: 'right', background: "#133a62", color: 'white' }}>My Retros</MenuItem>

                  <MenuItem style={{ textAlign: 'right', background: "#133a62", color: 'white' }}>My Templates</MenuItem>
                  <MenuItem onClick={() => this.logout()} style={{ textAlign: 'right', background: "#133a62" }}>Sign Out</MenuItem>
                </NavDropdown>
              </Nav>
            </Navbar.Collapse>
          </Navbar>
          <Tabs defaultActiveKey={1} id="uncontrolled-tab-example">
            <Tab eventKey={1} title={<div style={{display:'inline-flex'}}><Icon icon={checkCircle} size={20} /><p style={{paddingLeft:5}}>Create Retro</p></div>}>
              <div style={{ display: 'inline-flex', width: '100%' }}>

                <div style={{ width: '40%', display: 'inline-flex', justifyContent: 'center' }}>
                  <div style={{ width: '80%' }}>
                    <div>

                      <h4 style={{ color:  "#133a62",fontWeight:"bold" }}>
                        Project Information
            </h4>
                      <Form style={{ width: '100%' }} inline>
                      

                        {
                        
                            this.state.nameofproject === "true" ? 
                            <FormGroup controlId="formInlineEmail">

                            <FormControl size={30} onChange={(evt) => this.setState({nameofproject: evt.target.value})} 
                            style={{ marginLeft: 10 }} type="text" placeholder="Enter Project Information" />
                            {/* <Button onClick={() => this.setState({projectname:false})} bsStyle="primary" bsSize="small">Done</Button> */}
                          </FormGroup>
                            :
                        <FormControl onChange={(evt) => this.getprojectnam(evt) } bsSize="medium"  style={{ width: '75%' }} componentClass="select">
                          <option name="Projectname" value="Project Name">Project Name</option>
                          <option name="Projectname" value="Dance Technologies Android App">Dance Technologies Android App</option>
                          <option name="Projectname" value="DKG">DKG</option>
                          <option name="Projectname" value="Donut Guy Website">Donut Guy Website</option>
                          <option name="Projectname" value="DIY App">DIY App</option>


                          <option name="Projectname" value="New Project" style={{ background: "#133a62", color: 'white' }}>
                            {/* <i> <Icon icon={ic_close} size={10}/></i> */}
                            New Project
                          </option>

                        </FormControl>}

                        <FormGroup controlId="formInlineEmail">

                          <FormControl size={12} style={{ marginLeft: 10 }} type="email" placeholder="Sprint Number" />
                        </FormGroup>

                      </Form>
                      <p style={{ display: 'flex', justifyContent: 'flex-end' }}>

                        <a>
                          optional
          </a>
                      </p>
                    </div>
                    <div>

                      <h4 style={{ color:  "#133a62",fontWeight:"bold" }}>
                        Choose a Template:
            </h4>

                      <div>

                        <div style={{ display: 'inline-flex', width: '100%', height: 40, background: '#f6f6f6' }}>

                          <Icon icon={caretRight} size={20} style={{ marginTop: 8, color: "#f3764e" }} />
                          {/* <FormGroup
            controlId="formBasicText"
          >

            <FormControl
              type="text"
              size={48}
              placeholder="Sprint Ceremonies"
              onChange={this.handleChange}
            />

          </FormGroup> */}


                          <FormControl bsSize="medium" style={{ width: '95%' }} onChange={(evt) => this.gettemplatename(evt)}
                          componentClass="select" formva placeholder="Sprint Ceremonies">
                            <option name="Template"  disabled>Default Templates</option>
                            <option name="Template" value="Sprint Ceremonies">Sprint Ceremonies</option>
                            <option name="Template" value="Product Launch">Product Launch</option>
                            <option name="Template" value="Failed Sprint">Failed Sprint</option>
                            <option name="Template" value="Client Check-in">Client Check-in</option>
                            <option name="Template" disabled>My Templates</option>
                            <option name="Template" value="Dance Technologies Template">Dance Technologies Template</option>
                            <option name="Template" value="Bob's Retro Template">Bob's Retro Template</option>
                            <option name="Template" value="New Template" style={{ background: "#133a62", color: 'white' }}>
                              {/* <i> <Icon icon={ic_close} size={10}/></i> */}
                              New Template
            </option>

                          </FormControl>

                        </div>
                      </div>
                    </div>

                    <div style={{ display: 'inline-flex', width: '100%', justifyContent: "space-between", paddingTop: 50 }}>

                      <h4 style={{ color:  "#133a62",fontWeight:"bold" }}>
                        Retro Categories
                      </h4>
                      <Button bsSize="xsmall" style={{ borderRadius: 15, width: 75, height: 25, alignSelf: 'center' }} 
                      bsStyle="primary" onClick={() => this.setState({show1:true})}>Edit</Button>

                    </div>

                    {
                      this.state.show1 ?
                     

                      <div>
                      <h6 style={{color:'#aaabad',fontSize:16}}>Enter these catogories by typing over them</h6>
                    <div style={{ width: '100%', background: '#f6f6f6', paddingLeft: 15, height: 50, display: 'flex', alignItems: 'center' }}>
                   <FormControl size={20} onChange={(evt) => this.setState({whatdidwemiss: evt.target.value})} 
                      style={{}} type="text" placeholder="What went well" />
                  </div>
                  <div style={{ width: '100%', background: '#f6f6f6', paddingLeft: 15, height: 50, display: 'flex', alignItems: 'center', marginTop: 10 }}>
                    
                    <FormControl size={20} onChange={(evt) => this.setState({whatdidwelearn: evt.target.value})} 
                      style={{}} type="text" placeholder="What did we learn?" />
                  </div>
                  <div style={{ width: '100%', background: '#f6f6f6', paddingLeft: 15, height: 50, display: 'flex', alignItems: 'center', marginTop: 10 }}>
                    
                      <FormControl size={20} onChange={(evt) => this.setState({whatcanweimprove: evt.target.value})} 
                      style={{}} type="text" placeholder="What can we improve?" />
                  </div>
                  <div style={{ width: '100%', background: '#f6f6f6', paddingLeft: 15, height: 50, display: 'flex', alignItems: 'center', marginTop: 10 }}>
                 
                   <FormControl size={20} onChange={(evt) => this.setState({whatpuzzlesus: evt.target.value})} 
                      style={{}} type="text" placeholder="What puzzles us?" />
                  </div>  
                </div>
                     :

                        <div>

                    <div style={{ width: '100%', background: '#f6f6f6', paddingLeft: 15, height: 50, display: 'flex', alignItems: 'center' }}>
                      <h4 >What went well?</h4>
                    </div>
                    <div style={{ width: '100%', background: '#f6f6f6', paddingLeft: 15, height: 50, display: 'flex', alignItems: 'center', marginTop: 10 }}>
                      <h4>What did we learn?</h4>
                    </div>
                    <div style={{ width: '100%', background: '#f6f6f6', paddingLeft: 15, height: 50, display: 'flex', alignItems: 'center', marginTop: 10 }}>
                      <h4>What can we improve?</h4>
                    </div>
                    <div style={{ width: '100%', background: '#f6f6f6', paddingLeft: 15, height: 50, display: 'flex', alignItems: 'center', marginTop: 10 }}>
                      <h4>What puzzles us?</h4>
                    </div>   

                        </div>

}
                      {
                        this.state.templatename === "New Template" ? 
                        
                      <div style={{width:'100%',background:'red',display:'inline-flex',justifyContent:'space-evenly'}}>
                        
                        <FormControl  style={{ marginLeft: 10 ,width:'80%',height:50,}} type="text" placeholder="" />
                        <Button bsSize="large" style={{borderRadius:0,background:"#3b75fa",color:'white'}}>Save</Button>
                      </div>
                        
                        : 
                        ""
                        
                      }



                  </div>

                </div>
              <div style={{ width: '60%', display: 'inline-flex', justifyContent: 'space-evenly', paddingTop: '12%', paddingLeft: '4%', height: 540 }}>
                  
                  <div style={{ width: "20%", background: '#f3e2d8' }}>
                    <h6 style={{ textAlign: 'center', }}>What went well</h6>
                  </div>

                  <div style={{ width: "20%", background: '#f3e2d8' }}>
                    <h6 style={{ textAlign: 'center' }}>What did we learn</h6>
                  </div>

                  <div style={{ width: "20%", background: '#f3e2d8' }}>
                    <h6 style={{ textAlign: 'center' }}>What can we improve</h6>
                  </div>

                  <div style={{ width: "20%", background: '#f3e2d8' }}>
                    <h6 style={{ textAlign: 'center' }}>What Puzzles</h6>
                  </div>
                </div>
              </div>
              <div style={{ display: 'inline-flex', justifyContent: 'center', width: "100%" }}>
                <Button bsStyle="primary" bsSize="lg" style={{ width: '12%', marginTop: '5%',background:'#7289a1' }}>
                  Next
        </Button>

              </div>
            </Tab>
            <Tab eventKey={2} title="Invite team">
              Tab 2 content
                  </Tab>

          </Tabs>

        </div>
        <Modal
          show={this.state.show}
          onHide={() => this.handleHide()}
          container={this}
          aria-labelledby="contained-modal-title"
        >
          <Modal.Header closeButton>
            <Modal.Title id="contained-modal-title">
                Enter Project Name              
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
          <FormControl size={20} onChange={(evt) => this.setState({nameofproject: evt.target.value})} 
                            style={{}} type="text"  />
          </Modal.Body>
          <Modal.Footer>
            <Button onClick={() => this.handleHide()}>Done</Button>
          </Modal.Footer>
        </Modal>


        {/* <Modal
          show={this.state.show1}
          onHide={() => this.handleHide1()}
          container={this}
          aria-labelledby="contained-modal-title"
        >
          <Modal.Header closeButton>
            <Modal.Title id="contained-modal-title">
                Enter Template Name              
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
          <FormControl size={20} onChange={(evt) => this.setState({templatename: evt.target.value})} 
                            style={{}} type="text"  />
          </Modal.Body>
          <Modal.Footer>
            <Button onClick={() => this.handleHide()}>Done</Button>
          </Modal.Footer>
        </Modal> */}
      </div>
    );
  }
}


export default Createretro;